package com.capgemini.barclays.cards.poc.jgroups.distributed;

import org.axonframework.commandhandling.AggregateAnnotationCommandHandler;
import org.axonframework.commandhandling.CommandBus;
import org.axonframework.commandhandling.CommandMessage;
import org.axonframework.commandhandling.SimpleCommandBus;
import org.axonframework.commandhandling.distributed.AbstractRoutingStrategy;
import org.axonframework.commandhandling.distributed.DistributedCommandBus;
import org.axonframework.commandhandling.distributed.RoutingStrategy;
import org.axonframework.commandhandling.distributed.UnresolvedRoutingKeyPolicy;
import org.axonframework.commandhandling.distributed.commandfilter.AcceptAll;
import org.axonframework.commandhandling.gateway.CommandGateway;
import org.axonframework.commandhandling.gateway.DefaultCommandGateway;
import org.axonframework.commandhandling.model.Repository;
import org.axonframework.eventsourcing.EventSourcingRepository;
import org.axonframework.eventsourcing.eventstore.EmbeddedEventStore;
import org.axonframework.eventsourcing.eventstore.EventStore;
import org.axonframework.eventsourcing.eventstore.inmemory.InMemoryEventStorageEngine;
import org.axonframework.jgroups.commandhandling.JGroupsConnector;
import org.axonframework.serialization.xml.XStreamSerializer;
import org.jgroups.JChannel;
import org.jgroups.View;
import org.springframework.stereotype.Component;

@Component
public class PrimaryNode {

	private JGroupsConnector connector;

	private JChannel channel;

	private CommandGateway commandGateway;

	private EventStore eventStore;

	private CommandBus commandBus;

	public PrimaryNode() {

		eventStore = new EmbeddedEventStore(new InMemoryEventStorageEngine());

		try {

			commandBus = configureDistributedCommandBus();

		} catch (Exception e) {

			e.printStackTrace();
		}

		Repository<Item> repository = new EventSourcingRepository<>(Item.class, eventStore);

		new AggregateAnnotationCommandHandler<>(Item.class, repository).subscribe(commandBus);

		commandGateway = new DefaultCommandGateway(commandBus);
	}

	public void run() {

		for (int a = 0; a < 5; a++) {

			System.out.println("Primary Node Created item " + a + " id: " + System.currentTimeMillis());
			commandGateway.sendAndWait(new CreateItem(Long.toString(System.currentTimeMillis()),
					Long.toString(System.currentTimeMillis())));
		}
	}

	private CommandBus configureDistributedCommandBus() throws Exception {

		CommandBus commandBus = new SimpleCommandBus();

		channel = new JChannel(getClass().getClassLoader().getResourceAsStream("tcp.xml"));

		RoutingStrategy rs = new AbstractRoutingStrategy(UnresolvedRoutingKeyPolicy.STATIC_KEY) {

			@Override
			protected String doResolveRoutingKey(CommandMessage<?> cmdMsg) {

				View view = channel.getView();

				if (view.getMembers().size() == 2) {

					return "secondary";

				} else if (view.getMembers().size() == 1) {

				}

				return cmdMsg.getIdentifier();
			}
		};

		connector = new JGroupsConnector(commandBus, channel, "axon-jgroups-demo", new XStreamSerializer(), rs);
		connector.updateMembership(100, AcceptAll.INSTANCE);

		connector.connect();
		connector.awaitJoined();

		return new DistributedCommandBus(connector, connector);
	}
}
