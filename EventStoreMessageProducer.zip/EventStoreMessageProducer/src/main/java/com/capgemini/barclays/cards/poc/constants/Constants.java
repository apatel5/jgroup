package com.capgemini.barclays.cards.poc.constants;

public class Constants {

	public static final String JGROUPS_CONFIG_FILE = "jgroups-config.properties";
	public static final String CLUSTER_NAME = "clustername";
}
