package com.capgemini.barclays.cards.poc;

import org.springframework.stereotype.Component;

@Component
public class InitializeJGroupsReceiver {

	/*@Autowired
	private JGroupsRequestReceiver jGroupsRequestReceiver;

	@PostConstruct
	public void init() {

		try {

			jGroupsRequestReceiver.initializeChannel();

		} catch (Exception e) {

			e.printStackTrace();
		}
	}*/
}
