package com.capgemini.barclays.cards.poc.util;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class ConfigurationReader {

	public static Properties getConfigurationFromFile(String filename) {

		Properties properties = new Properties();
		InputStream input = null;

		try {

			input = ConfigurationReader.class.getClassLoader().getResourceAsStream(filename);

			properties.load(input);

		} catch (IOException ex) {

			ex.printStackTrace();

		} finally {

			if (input != null) {

				try {

					input.close();

				} catch (IOException e) {

					e.printStackTrace();
				}
			}
		}

		return properties;
	}
}
