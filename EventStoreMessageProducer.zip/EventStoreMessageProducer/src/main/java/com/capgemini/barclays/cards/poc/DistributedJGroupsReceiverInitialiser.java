package com.capgemini.barclays.cards.poc;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.capgemini.barclays.cards.poc.jgroups.distributed.SecondaryNode;

@Component
public class DistributedJGroupsReceiverInitialiser {

	@Autowired
	private SecondaryNode secondaryNode;

	@PostConstruct
	public void init() {

		try {

			secondaryNode.run();

		} catch (Exception e) {

			e.printStackTrace();
		}
	}
}
