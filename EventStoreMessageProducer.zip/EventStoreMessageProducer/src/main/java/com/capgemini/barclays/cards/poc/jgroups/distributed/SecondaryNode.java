package com.capgemini.barclays.cards.poc.jgroups.distributed;

import org.axonframework.commandhandling.AggregateAnnotationCommandHandler;
import org.axonframework.commandhandling.CommandBus;
import org.axonframework.commandhandling.SimpleCommandBus;
import org.axonframework.commandhandling.distributed.AnnotationRoutingStrategy;
import org.axonframework.commandhandling.distributed.DistributedCommandBus;
import org.axonframework.commandhandling.distributed.commandfilter.AcceptAll;
import org.axonframework.commandhandling.model.Repository;
import org.axonframework.eventhandling.EventListener;
import org.axonframework.eventhandling.SimpleEventHandlerInvoker;
import org.axonframework.eventhandling.SubscribingEventProcessor;
import org.axonframework.eventsourcing.EventSourcingRepository;
import org.axonframework.eventsourcing.eventstore.EmbeddedEventStore;
import org.axonframework.eventsourcing.eventstore.EventStore;
import org.axonframework.eventsourcing.eventstore.inmemory.InMemoryEventStorageEngine;
import org.axonframework.jgroups.commandhandling.JGroupsConnector;
import org.axonframework.serialization.xml.XStreamSerializer;
import org.jgroups.JChannel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.capgemini.barclays.cards.poc.activemq.Producer;

@Component
public class SecondaryNode {

	@Autowired
	private Producer producer;

	private JGroupsConnector connector;

	private CommandBus commandBus;

	private EventStore eventStore;

	private static int msgs;

	public SecondaryNode() throws Exception {

		eventStore = new EmbeddedEventStore(new InMemoryEventStorageEngine());

		commandBus = configureDistributedCommandBus();

		Repository<Item> repository = new EventSourcingRepository<>(Item.class, eventStore);

		new AggregateAnnotationCommandHandler<>(Item.class, repository).subscribe(commandBus);

		new SubscribingEventProcessor("processor", new SimpleEventHandlerInvoker((EventListener) event -> {

			msgs++;
			System.out.println(msgs);
			System.out.println("Secondary node -- " + event.getPayload());

			producer.send(event.getPayload().toString());

		}), eventStore).start();
	}

	public void run() {

	}

	private CommandBus configureDistributedCommandBus() throws Exception {

		CommandBus commandBus = new SimpleCommandBus();

		JChannel channel = new JChannel(getClass().getClassLoader().getResourceAsStream("tcp_test.xml"));

		connector = new JGroupsConnector(commandBus, channel, "axon-jgroups-demo", new XStreamSerializer(),
				new AnnotationRoutingStrategy());
		connector.updateMembership(100, AcceptAll.INSTANCE);

		connector.connect();
		connector.awaitJoined();

		return new DistributedCommandBus(connector, connector);
	}
}
