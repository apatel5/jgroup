package com.capgemini.barclays.cards.poc;

import javax.jms.ConnectionFactory;

import org.apache.activemq.ActiveMQConnectionFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
@EnableAutoConfiguration
public class EventStoreMessageProducerApplication {

	public static void main(String[] args) {

		SpringApplication.run(EventStoreMessageProducerApplication.class, args);

	}

	@Bean
	public ConnectionFactory ConnectionFactory(@Value("${broker.url}") String url) {
		ActiveMQConnectionFactory activeMQConnectionFactory = new ActiveMQConnectionFactory();
		activeMQConnectionFactory.setBrokerURL(url);
		return activeMQConnectionFactory;
	}
}
