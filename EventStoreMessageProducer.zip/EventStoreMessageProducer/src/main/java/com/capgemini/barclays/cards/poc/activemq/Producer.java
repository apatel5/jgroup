package com.capgemini.barclays.cards.poc.activemq;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.core.JmsMessagingTemplate;
import org.springframework.stereotype.Component;

@Component
public class Producer {

	@Autowired
	private JmsMessagingTemplate jmsMessagingTemplate;

	public void writeMessage(String message) throws Exception {

		send(message);
	}

	public void send(String msg) {

		System.out.println("Writing message on queue - " + msg);

		this.jmsMessagingTemplate.convertAndSend("iTest", msg);
	}
}