package com.capgemini.barclays.cards.poc.jgroups;

import org.jgroups.ReceiverAdapter;
import org.springframework.stereotype.Component;

@Component
public class JGroupsRequestReceiver extends ReceiverAdapter {

	/*@Autowired
	Channel channel;

	@Autowired
	Producer producer;

	public void initializeChannel() throws Exception {

		channel.setReceiver(this);
	}

	public void viewAccepted(View new_view) {

		System.out.println("** view: " + new_view);

	}

	public void receive(Message msg) {

		System.out.println(msg.getSrc() + ": " + msg.getObject());

		try {

			producer.writeMessage((String) msg.getObject());

		} catch (Exception e) {

			e.printStackTrace();
		}
	}*/
}
