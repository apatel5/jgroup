package com.capgemini.barclays.cards.poc.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.capgemini.barclays.cards.poc.jgroups.distributed.PrimaryNode;

@Controller
@RequestMapping(value = "/jgroups")
public class DistributedJGroupsController {

	@Autowired
	PrimaryNode primaryNode;

	@RequestMapping(value = "/run")
	public void run() {

		primaryNode.run();
	}
}