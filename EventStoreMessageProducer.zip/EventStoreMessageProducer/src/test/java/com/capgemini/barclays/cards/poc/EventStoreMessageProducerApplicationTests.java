package com.capgemini.barclays.cards.poc;

import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class EventStoreMessageProducerApplicationTests {

	@Test
	public void contextLoads() {

		JGroupsTestNode.initializeChannel();

		for (int i = 0; i < 10; i++) {

			assertTrue(JGroupsTestNode.broadcastMessageOnCluster(System.currentTimeMillis() + ""));
		}

		// JGroupsTestNode.closeChannel();
	}
}