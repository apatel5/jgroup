package com.capgemini.barclays.cards.poc;

import org.jgroups.Channel;
import org.jgroups.JChannel;
import org.jgroups.Message;

public class JGroupsTestNode {

	private static Channel channel;

	public static void initializeChannel() {

		try {

			channel = new JChannel("tcp_test.xml");
			channel.connect("localcluster");

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static boolean broadcastMessageOnCluster(String message) {

		Message msg = new Message(null, null, message);

		try {

			channel.send(msg);

			System.out.println("Sending message on channel - " + msg);

		} catch (Exception e) {

			e.printStackTrace();

			return false;
		}

		return true;
	}

	public static void closeChannel() {

		channel.close();
	}

	public static void main(String[] args) {

		initializeChannel();

		for (int i = 0; i < 10; i++) {

			broadcastMessageOnCluster(System.currentTimeMillis() + "");
		}

		// closeChannel();
	}
}
